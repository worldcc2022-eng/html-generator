<?php
declare(strict_types=1);
/** Private FCKeditor 2.x compatibility lab. Not for public deployment. */
$id = (string)($_GET['jd'] ?? $_GET['id'] ?? 'video-ufc-334-en-ufc-pass-tv487619');
if (!preg_match('/\A[a-z0-9][a-z0-9-]{7,179}\z/D', $id)) {
    http_response_code(400);
    exit('Invalid generated HTML ID.');
}
$labConnector = '/connector-router/editor-lab/connector.php?jd=' . rawurlencode($id);
$browser = 'fckeditor/editor/filemanager/browser/default/browser.html?Type=File&Connector=' . rawurlencode($labConnector);
$xml = $labConnector . '&Command=GetFoldersAndFiles&Type=File&CurrentFolder=%2F';
$esc = static fn(string $v): string => htmlspecialchars($v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Content-Type: text/html; charset=UTF-8');
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Private FCKeditor 2.x Compatibility Lab</title>
<style>
:root{font-family:system-ui,-apple-system,Segoe UI,sans-serif;color-scheme:light;background:#f4f6fa;color:#1d2839}body{margin:0}.wrap{max-width:1160px;margin:auto;padding:30px 20px}h1{font-size:24px}p{line-height:1.55}.notice{background:#fff8e5;border:1px solid #eed37d;padding:12px;border-radius:10px}.actions{display:flex;gap:12px;flex-wrap:wrap;align-items:end;background:#fff;border:1px solid #e0e5ee;border-radius:10px;padding:20px;margin:20px 0}label{display:block;font-size:14px;font-weight:700;margin-bottom:6px}input{width:min(500px,85vw);padding:11px;border:1px solid #bcc4d1;border-radius:8px;font:inherit}button,.link{display:inline-block;padding:12px 16px;background:#1e4d9a;color:#fff;border-radius:8px;text-decoration:none;border:none;cursor:pointer;font:inherit}.link.secondary{background:#e7ebf2;color:#1d2839}code{overflow-wrap:anywhere}section{background:white;border:1px solid #e0e5ee;border-radius:12px;padding:20px}small{color:#526176}
</style></head><body><main class="wrap"><h1>FCKeditor 2.x — Private Compatibility Lab</h1>
<p class="notice">Legacy software is unmaintained. This installation is password-protected and its bundled upload/server connectors are blocked. Use the editor only to test your own XML connector and generated GitHub Pages file mapping.</p>
<form class="actions" method="get"><div><label for="jd">Existing HTML Generator ID</label><input name="jd" id="jd" required pattern="[a-z0-9][a-z0-9-]{7,179}" value="<?= $esc($id) ?>" /></div><button>Load ID</button><a class="link secondary" href="<?= $esc($browser) ?>" target="_blank" rel="noopener">Open legacy file browser</a><a class="link secondary" href="<?= $esc($xml) ?>" target="_blank" rel="noopener">Inspect XML</a></form>
<p><small>Browser connector: <code><?= $esc($labConnector) ?></code></small></p>
<section><h2>Editor</h2><script src="fckeditor/fckeditor.js"></script><script>
(function () {
    const browserUrl = <?= json_encode($browser, JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_SLASHES) ?>;
    if (typeof FCKeditor !== 'function') {
        document.write('<p>The original FCKeditor package is not installed. Run the install script first.</p>');
        return;
    }
    const editor = new FCKeditor('CompatibilityEditor');
    editor.BasePath = 'fckeditor/';
    editor.Height = '380';
    editor.Width = '100%';
    editor.Value = '<p>Test editor. Use the Link toolbar button and select Browse Server to inspect the matching GitHub Pages file.</p>';
    editor.Config['LinkBrowser'] = true;
    editor.Config['LinkBrowserURL'] = browserUrl;
    editor.Config['LinkUpload'] = false;
    editor.Config['ImageUpload'] = false;
    editor.Config['FlashUpload'] = false;
    editor.Config['ImageBrowser'] = false;
    editor.Config['FlashBrowser'] = false;
    editor.Config['AutoDetectLanguage'] = false;
    editor.Config['DefaultLanguage'] = 'en';
    editor.Create();
})();
</script></section>
<p><small>This lab does not upload event HTML files. Keep using your existing HTML Generator and its GitHub deployment, then register the filenames through your Connector's GitHub Pages Mapping dashboard.</small></p>
</main></body></html>
