<?php
declare(strict_types=1);
/** Read-only XML adaptor for our own protected legacy FCKeditor browser. */
header('Content-Type: text/xml; charset=UTF-8');
header('Cache-Control: no-store, private');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

function xmlEscape(string $value): string {
    return htmlspecialchars($value, ENT_XML1 | ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function xmlError(int $status, string $message): never {
    http_response_code($status);
    echo '<?xml version="1.0" encoding="UTF-8"?><Connector><Error number="1" text="' . xmlEscape($message) . '"/></Connector>';
    exit;
}
$root = dirname(__DIR__);
if (!is_file($root . '/bootstrap.php') || !is_file($root . '/lib/GithubPages.php')) {
    xmlError(503, 'Connector Router and GitHub Pages mapping module are required.');
}
require_once $root . '/bootstrap.php';
require_once $root . '/lib/GithubPages.php';

$id = (string)($_GET['jd'] ?? '');
$command = (string)($_GET['Command'] ?? 'GetFoldersAndFiles');
$type = (string)($_GET['Type'] ?? 'File');
$folder = (string)($_GET['CurrentFolder'] ?? '/');
if (!cr_valid_id($id)) xmlError(400, 'Invalid generated ID.');
if (!in_array($type, ['File', 'Document'], true)) xmlError(400, 'Unsupported resource type.');
if ($folder !== '/') xmlError(400, 'Only root folder listing is supported.');
if (!in_array($command, ['GetFolders', 'GetFoldersAndFiles'], true)) xmlError(405, 'Read-only connector.');
try {
    $base = cr_gp_base_for_id($id);
    if ($base === '') xmlError(404, 'Configure the GitHub Pages folder first.');
    $filename = $id . '.html';
    $fileUrl = cr_gp_file_url($id);
    // GitHub Pages mapping is administered separately; this endpoint does not fetch external URLs.
    $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml .= '<Connector command="' . xmlEscape($command) . '" resourceType="' . xmlEscape($type) . '">' . "\n";
    $xml .= '  <CurrentFolder path="/" url="' . xmlEscape($base) . '"/>' . "\n";
    $xml .= '  <Folders/>' . "\n";
    if ($command === 'GetFoldersAndFiles') {
        $xml .= '  <Files><File name="' . xmlEscape($filename) . '" size="0" desc="1" url="' . xmlEscape($fileUrl) . '"/></Files>' . "\n";
    }
    $xml .= "</Connector>\n";
    echo $xml;
} catch (Throwable $e) {
    xmlError(400, 'Could not resolve this ID to a configured GitHub Pages folder.');
}
