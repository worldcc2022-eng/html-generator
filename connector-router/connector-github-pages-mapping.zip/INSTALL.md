# GitHub Pages file mapping — Connector Router update

This update is designed **only** for your existing installation at:

- Files: `/home/surprisehtml/public_html/connector-router/`
- Website: `https://html.surprisestream.com/connector-router/`

It is an overlay, not a new installation. It does **not** contain `config.local.php`, `lib/Core.php`, the admin authentication files, existing routes, template files, generated HTML, or GitHub access credentials.

## Functionality

1. Manual GitHub Pages **folder URL**. Example: `https://mygithubpage.io/id/` or `https://username.github.io/repository/id/`.
2. Existing generated filenames or IDs, one per line: `video-ufc-334-en-ufc-pass-tv487619.html`.
3. Each ID maps to the exact matching `<id>.html` file on the supplied GitHub Pages folder. No renamed IDs, no additional files.
4. Saved **per-ID mapping**, so changing the default folder does not break already mapped IDs.
5. Valid XML from `/id/?jd=<id>`: a `CurrentFolder` URL and a `File` entry containing `name`, `desc`, `size="0"`, and the destination `url`.
6. First-party file browser uses the XML response to offer **Open** and sandboxed **Preview**. No automatic navigation or code injection on external websites.
7. Bulk mappings from `bulk-links.php`, `github-pages.php`, or `github-bulk-import.php`.
8. No HTTP request is made to GitHub Pages at mapping time. The user must verify that the previously uploaded HTML file exists on the public GitHub Pages deployment.

## Install safely

**1.** Upload `connector-github-pages-mapping.zip` to `/home/surprisehtml/public_html/connector-router/`.

**2.** Back up only files replaced by this patch:

```bash
cd /home/surprisehtml/public_html/connector-router || exit 1
BACKUP="/home/surprisehtml/connector-github-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP/assets" "$BACKUP/id"
for f in bulk-links.php bulk-export.php assets/browser.js id/index.php; do
  if [ -f "$f" ]; then cp -p "$f" "$BACKUP/$f"; fi
done
printf 'Backup: %s\n' "$BACKUP"
```

**3.** Extract into the current folder (this ZIP has no top-level directory):

```bash
unzip -o connector-github-pages-mapping.zip
chown -R surprisehtml:surprisehtml \
  lib/GithubPages.php github-pages.php github-bulk-import.php \
  bulk-links.php bulk-export.php id/index.php assets/browser.js \
  bin/github-smoke.php INSTALL.md GENERATOR-INTEGRATION-PROMPT.md
```

**4.** Check PHP syntax and local routing calculations:

```bash
for f in lib/GithubPages.php github-pages.php github-bulk-import.php \
  bulk-links.php bulk-export.php id/index.php bin/github-smoke.php; do
    php -l "$f" || exit 1
 done
runuser -u surprisehtml -- php bin/github-smoke.php
```

**5.** Log in (the existing 30-day admin login patch is not changed):

`https://html.surprisestream.com/connector-router/admin.php`

Then open the new setting and batch form:

`https://html.surprisestream.com/connector-router/github-pages.php`

Alternatively use the updated:

`https://html.surprisestream.com/connector-router/bulk-links.php`

**6.** Enter the actual folder holding `.html` pages, paste your generated filenames and click **Generate matching URLs**.

**7.** Test the XML endpoint:

```bash
curl -sS 'https://html.surprisestream.com/connector-router/id/?jd=video-ufc-334-en-ufc-pass-tv487619'
```

The generated file URL must be identical to your GitHub Pages URL plus the existing ID plus `.html`.

## API for HTML Generator

`POST https://html.surprisestream.com/connector-router/github-bulk-import.php`

Header `Authorization: Bearer <private API token from existing config.local.php>`; `Content-Type: application/json`.

Example payload:

```json
{
  "github_pages_base": "https://mygithubpage.io/id/",
  "filenames": [
    "video-ufc-334-en-ufc-pass-tv487619.html",
    "video-another-match-q1w2e3.html"
  ],
  "overwrite": false,
  "save_default": false
}
```

Returns `count` and `links[]`: `filename`, `id`, `github_url`, `url` (first-party browser URL), `status`.

Keep the API token server-side. Do not insert it into generated HTML, query strings, or JS code.

For up to 1000 URLs per batch, split larger jobs into consecutive requests, but **do not mint new IDs**. Only call the API after GitHub deploy succeeds, so URLs are not published for pending/missing files.

## Limitations

- Does not upload HTML templates: existing HTML Generator already handles that.
- Does not upload to GitHub: your existing GitHub deployment workflow remains responsible.
- Does not confirm a GitHub Pages deployment is live or that files exist. Verify a sample file directly in a browser.
- Does not execute injected HTML in external FCKeditor installations, and will not generate external FCKeditor exploit links. The demo browser is hosted under your own Connector installation.
- A GitHub Pages server may prevent iframe previews through frame policies; use the **Open** link to test the page directly.
