<?php
declare(strict_types=1);
require dirname(__DIR__) . '/bootstrap.php';
require_once dirname(__DIR__) . '/lib/GithubPages.php';
cr_no_cache();
header('Content-Type: application/xml; charset=UTF-8');
header('X-Content-Type-Options: nosniff');
try {
    $command = (string)($_GET['Command'] ?? 'GetFoldersAndFiles');
    $type = (string)($_GET['Type'] ?? 'File');
    if ($command !== 'GetFoldersAndFiles' || !in_array($type, ['File', 'Document'], true)) {
        throw new InvalidArgumentException('Unsupported connector command or resource type');
    }
    $id = $_GET['jd'] ?? $_GET['id'] ?? '';
    if (!is_string($id)) throw new InvalidArgumentException('Missing or invalid jd ID');
    echo cr_gp_xml_document($id);
} catch (Throwable $e) {
    http_response_code(400);
    echo '<?xml version="1.0" encoding="UTF-8"?><Connector><Error number="1" text="' . cr_xml($e->getMessage()) . '"/></Connector>';
}
