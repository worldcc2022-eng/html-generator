<?php
declare(strict_types=1);
require __DIR__.'/bootstrap.php';
cr_no_cache();
header('Content-Type: application/xml; charset=UTF-8');
$command = (string)($_GET['Command'] ?? 'GetFoldersAndFiles');
$type = (string)($_GET['Type'] ?? 'File');
if ($command !== 'GetFoldersAndFiles' || !in_array($type, ['File','Document'], true)) {
    http_response_code(400);
    echo '<?xml version="1.0" encoding="UTF-8"?><Connector><Error number="1" text="Unsupported command or type"/></Connector>';
    exit;
}
$id = (string)($_GET['id'] ?? '');
$routes = $id !== '' ? array_filter([cr_route_get($id)]) : cr_latest_routes(50);
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<Connector command="GetFoldersAndFiles" resourceType="Document">' . "\n";
echo '  <CurrentFolder path="/" url="/"/>' . "\n";
echo "  <Folders/>\n  <Files>\n";
foreach ($routes as $route) {
    $name = cr_xml($route['id'].'.html');
    $description = cr_xml($route['title']);
    $url = cr_xml(cr_route_url($route['id']));
    echo '    <File name="'.$name.'" size="0" desc="'.$description.'" url="'.$url.'"/>' . "\n";
}
echo "  </Files>\n</Connector>\n";
