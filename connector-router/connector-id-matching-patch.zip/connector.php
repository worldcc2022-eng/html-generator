<?php
declare(strict_types=1);
require __DIR__.'/bootstrap.php';
require_once __DIR__.'/lib/GithubPages.php';
cr_no_cache();
header('Content-Type: application/xml; charset=UTF-8');
$command = (string)($_GET['Command'] ?? 'GetFoldersAndFiles');
$type = (string)($_GET['Type'] ?? 'File');
if ($command !== 'GetFoldersAndFiles' || !in_array($type, ['File','Document'], true)) {
    http_response_code(400);
    echo '<?xml version="1.0" encoding="UTF-8"?><Connector><Error number="1" text="Unsupported command or type"/></Connector>';
    exit;
}
try {
    $id = cr_gp_request_id($_GET);
    if (!empty($crRequireGithubId) && $id === '') throw new InvalidArgumentException('Missing jd parameter');
    if ($id !== '' && (!empty($crRequireGithubId) || cr_gp_base_for_id($id) !== '')) {
        echo cr_gp_xml_document($id);
        exit;
    }
} catch (InvalidArgumentException $e) {
    http_response_code(400);
    echo '<?xml version="1.0" encoding="UTF-8"?><Connector><Error number="1" text="'.cr_xml($e->getMessage()).'"/></Connector>';
    exit;
} catch (RuntimeException $e) {
    http_response_code(503);
    echo '<?xml version="1.0" encoding="UTF-8"?><Connector><Error number="2" text="Configure the GitHub Pages directory in Admin settings first."/></Connector>';
    exit;
}
$routes = $id !== '' ? array_filter([cr_route_get($id)]) : cr_latest_routes(50);
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<Connector command="GetFoldersAndFiles" resourceType="Document">' . "\n";
echo '  <CurrentFolder path="/" url="/"/>' . "\n";
echo "  <Folders/>\n  <Files>\n";
foreach ($routes as $route) {
    $name = cr_xml($route['id'].'.html');
    $description = cr_xml($route['title']);
    $url = cr_xml(cr_route_url($route['id']));
    echo '    <File name="'.$name.'" size="0" desc="'.$description.'" url="'.$url.'"/>' . "\n";
}
echo "  </Files>\n</Connector>\n";
