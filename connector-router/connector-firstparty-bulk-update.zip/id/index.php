<?php
declare(strict_types=1);
// Compatible first-party endpoint: /id/?jd=video-existing-generated-file-id
// The browser adds Command, Type, CurrentFolder and uuid as in the recorded request.
$id = (string)($_GET['jd'] ?? '');
if ($id !== '') {
    require_once dirname(__DIR__) . '/bootstrap.php';
    if (!cr_valid_id($id)) {
        http_response_code(400);
        header('Content-Type: application/xml; charset=UTF-8');
        echo '<?xml version="1.0" encoding="UTF-8"?><Connector><Error number="1" text="Invalid ID"/></Connector>';
        exit;
    }
    $_GET['id'] = $id;
}
require dirname(__DIR__) . '/connector.php';
