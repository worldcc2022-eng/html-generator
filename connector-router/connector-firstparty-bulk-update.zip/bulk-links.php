<?php
declare(strict_types=1);
require __DIR__.'/bootstrap.php';
require_once __DIR__.'/lib/BulkLinks.php';
cr_require_admin();
$error = '';
$rows = [];
$input = '';
$requireRoutes = true;
$browserUrl = rtrim(cr_config()['base_url'], '/') . '/browser.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cr_csrf_check();
    $input = (string)($_POST['filenames'] ?? '');
    $requireRoutes = !empty($_POST['verify_routes']);
    $browserUrl = trim((string)($_POST['browser_url'] ?? $browserUrl));
    try {
        if (strlen($input) > 200000) throw new InvalidArgumentException('Input too large');
        $lines = array_values(array_filter(array_map('trim', preg_split('/\R/u', $input)), 'strlen'));
        $rows = cr_bulk_links($lines, $requireRoutes, $browserUrl);
    } catch (Throwable $e) { $error = $e->getMessage(); }
}
cr_html_headers();
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Bulk file browser URLs</title><link rel="stylesheet" href="assets/style.css"></head>
<body><main><div class="top"><h1>Bulk file browser URLs</h1><a href="admin.php">Admin</a></div>
<p>Paste your existing generated IDs or filenames, one per line. This creates links to your own browser at <code><?=cr_str(rtrim(cr_config()['base_url'],'/').'/browser.php')?></code>, without changing existing IDs or uploading HTML again.</p>
<?php if ($error): ?><div class="error"><?=cr_str($error)?></div><?php endif; ?>
<form method="post"><input type="hidden" name="csrf" value="<?=cr_str(cr_csrf())?>">
<label>Domain / browser URL (hosted by your Connector)<input type="url" name="browser_url" required value="<?=cr_str($browserUrl)?>"></label>
<label>Generated filenames / IDs<textarea name="filenames" rows="8" required placeholder="video-ufc-334-en-ufc-pass-tv487619.html"><?=cr_str($input)?></textarea></label>
<label class="check"><input type="checkbox" name="verify_routes" value="1" <?= $requireRoutes ? 'checked' : '' ?>>Require an existing imported route for every ID (recommended)</label>
<button type="submit">Generate first-party browser URLs</button></form>
<?php if ($rows): ?>
<section><h2>Results (<?=count($rows)?> unique IDs)</h2>
<label>Copy-ready URLs<textarea rows="9" readonly><?php foreach ($rows as $row) { if (isset($row['url'])) echo cr_str($row['url'])."\n"; } ?></textarea></label>
<table><thead><tr><th>Filename</th><th>URL or error</th></tr></thead><tbody><?php foreach ($rows as $row): ?><tr><td><?=cr_str($row['filename'])?></td><td class="wrap"><?php if (isset($row['url'])): ?><a href="<?=cr_str($row['url'])?>" target="_blank" rel="noopener"><?=cr_str($row['url'])?></a><?php else: ?><?=cr_str($row['error'])?><?php endif; ?></td></tr><?php endforeach; ?></tbody></table>
</section><?php endif; ?>
</main></body></html>
