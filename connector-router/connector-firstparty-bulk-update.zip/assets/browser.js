'use strict';
(() => {
  const status = document.getElementById('browser-status');
  const list = document.getElementById('file-results');
  const frame = document.getElementById('event-preview');
  const params = new URLSearchParams(window.location.search);
  const connectorValue = params.get('CONNECTOR');
  const configuredType = params.get('Type') || 'File';
  if (configuredType !== 'File' && configuredType !== 'Document') {
    status.textContent = 'Unsupported resource type';
    return;
  }
  const root = new URL(document.documentElement.dataset.connectorRoot || '.', window.location.href);
  const allowedPath = root.pathname + 'id/';
  let request;
  try {
    request = new URL(connectorValue || 'connector.php', root);
    if (request.origin !== window.location.origin ||
       (request.pathname !== allowedPath && request.pathname !== root.pathname + 'connector.php')) {
      throw new Error('Only the local, authorized connector can be used');
    }
    // Match the observed FCKeditor connector request parameters.
    request.searchParams.set('Command', 'GetFoldersAndFiles');
    request.searchParams.set('Type', configuredType);
    request.searchParams.set('CurrentFolder', '/');
    request.searchParams.set('uuid', String(Date.now()));
  } catch (error) {
    status.textContent = error.message;
    return;
  }
  fetch(request, {credentials: 'same-origin', redirect: 'error'})
    .then(async response => {
      if (!response.ok) throw new Error('HTTP ' + response.status);
      return await response.text();
    })
    .then(xmlText => {
      const doc = new DOMParser().parseFromString(xmlText, 'application/xml');
      if (doc.querySelector('parsererror')) throw new Error('Connector did not return valid XML');
      if (doc.documentElement.tagName !== 'Connector') throw new Error('Unexpected connector response');
      const error = doc.querySelector('Error');
      if (error) throw new Error(error.getAttribute('text') || 'XML error');
      const files = [...doc.querySelectorAll('Files > File')];
      status.textContent = files.length ? `${files.length} file(s) loaded` : 'No files found';
      for (const file of files) {
        const filename = file.getAttribute('name') || '';
        const desc = file.getAttribute('desc') || '';
        const id = filename.replace(/\.html$/i, '');
        if (!/^[a-z0-9][a-z0-9-]{7,179}$/.test(id)) continue;
        const tr = document.createElement('tr');
        const tdName = tr.insertCell(); tdName.textContent = filename;
        const tdDesc = tr.insertCell(); tdDesc.textContent = desc;
        const tdOpen = tr.insertCell();
        const route = new URL('go.php?id=' + encodeURIComponent(id), root);
        const link = document.createElement('a');
        link.href = route.href;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.textContent = 'Open';
        tdOpen.appendChild(link);
        tdOpen.appendChild(document.createTextNode(' · '));
        const button = document.createElement('button');
        button.type = 'button';
        button.textContent = 'Preview';
        button.addEventListener('click', () => { frame.src = route.href; });
        tdOpen.appendChild(button);
        list.appendChild(tr);
      }
    })
    .catch(error => { status.textContent = 'XML request failed: ' + error.message; });
})();
