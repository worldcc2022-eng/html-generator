<?php
declare(strict_types=1);
require __DIR__.'/bootstrap.php';
require_once __DIR__.'/lib/BulkLinks.php';
cr_no_cache();
header('Content-Type: application/json; charset=UTF-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); header('Allow: POST');
    echo json_encode(['error' => 'POST required']); exit;
}
$headers = function_exists('getallheaders') ? getallheaders() : [];
$auth = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? $headers['Authorization'] ?? $headers['authorization'] ?? '');
if (!preg_match('/\ABearer ([a-f0-9]{64})\z/D', $auth, $match) ||
    !hash_equals(cr_config()['api_token'], $match[1])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']); exit;
}
try {
    if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 2097152) throw new InvalidArgumentException('Payload too large');
    $input = file_get_contents('php://input', false, null, 0, 2097153);
    if ($input === false || strlen($input) > 2097152) throw new InvalidArgumentException('Payload too large');
    $payload = json_decode($input, true, 64, JSON_THROW_ON_ERROR);
    if (!is_array($payload) || !is_array($payload['filenames'] ?? null) ||
        !array_is_list($payload['filenames']) || count($payload['filenames']) > 1000) {
        throw new InvalidArgumentException('Provide an array of 1–1000 filenames');
    }
    $rows = cr_bulk_links($payload['filenames'], ($payload['verify_routes'] ?? true) !== false, isset($payload['browser_url']) ? (string)$payload['browser_url'] : null);
    $ok = array_values(array_filter($rows, static fn(array $row): bool => isset($row['url'])));
    $errors = array_values(array_filter($rows, static fn(array $row): bool => isset($row['error'])));
    http_response_code($errors ? 207 : 200);
    echo json_encode(['count'=>count($ok), 'error_count'=>count($errors), 'links'=>$ok, 'errors'=>$errors], JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()], JSON_UNESCAPED_SLASHES);
}
