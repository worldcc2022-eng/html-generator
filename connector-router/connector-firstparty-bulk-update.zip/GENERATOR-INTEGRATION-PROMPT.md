# Apply this to my existing PHP HTML Generator

My main HTML Generator runs at `https://html.surprisestream.com/` and my separate Connector Router is installed at `https://html.surprisestream.com/connector-router/`. The Connector Router already has an authenticated JSON import API (`import.php`) and was upgraded with `lib/BulkLinks.php`, `id/index.php`, `bulk-links.php`, and a first-party `browser.php`.

**Implement the integration in the actual existing generator source, not a second generator.** First inspect its current source code and take a backup. No source-code assumptions.

### Existing behavior to preserve
- Existing uploaded HTML template remains the source of HTML outputs; no second upload field.
- Existing random title selection, placeholders `{event_name}` and `{date}`, existing ID seeds and unique filename rules stay unchanged.
- Existing GitHub and own-server upload flows, event URL replacement, multiple domains, pending URL distribution, batch count, ZIP download, TXT download and history stay unchanged.
- Generated filename (without `.html`) is the ID used with `jd`. Example `video-ufc-334-en-ufc-pass-tv487619.html` => `jd=video-ufc-334-en-ufc-pass-tv487619`.
- Exactly one URL per generated file. Do not generate a second ID or add URLs when output mode changes.

### New settings
1. Add an output option `First-party File Browser URL` alongside the existing direct HTML URL mode.
2. In this mode, use **only the browser endpoint hosted on my authorized domain** at `https://html.surprisestream.com/connector-router/browser.php`. Reuse the generator's Domain field as the browser URL input in this mode, but only for the two first-party endpoints hosted under `https://html.surprisestream.com/connector-router/`: `/browser.php` and `/legacy/browser.html`. Validate it strictly and show the derived Connector endpoint read-only. No unrelated FCKeditor host or XSS/iframe XML injection.
3. Add a `Test XML` action that fetches the Connector endpoint on my own host and checks HTTP status, Content-Type, XML parse validity and the exact filename in the File list.

### Integration logic
- On each batch, after the generator allocates filenames, send `{id, destination, title, mode:302}` records via server-side HTTPS POST to `https://html.surprisestream.com/connector-router/import.php`, using the installed private API token in server configuration. Reject or report per-ID errors; never expose token in the browser.
- `destination` is the generated event's approved destination on a domain we own or have approval to use. Do not create an open redirect.
- Reuse the existing generated IDs, not new random tokens. Keep retries idempotent, preferably upserting only for routes from that batch where allowed.
- Generate links by loading `lib/BulkLinks.php` (if in the same PHP host) and calling `cr_bulk_browser_url($filename)` or implementing its exact first-party URL building behavior.
- Expected browser URL for ID `video-ufc-334-en-ufc-pass-tv487619`:
  `https://html.surprisestream.com/connector-router/browser.php?Type=File&CONNECTOR=%2Fconnector-router%2Fid%2F%3Fjd%3Dvideo-ufc-334-en-ufc-pass-tv487619`
- On the first-party browser, fetch XML from `/connector-router/id/?jd=...&Command=GetFoldersAndFiles&Type=File&CurrentFolder=%2F&uuid=...`, parse as XML and render file metadata as text. The viewer must click Open/Preview to navigate the registered route.
- Never add executable iframe or `srcdoc` JavaScript into XML metadata and never send payloads to a third-party FCKeditor installation.
- Maintain current pending-URL redistribution behavior; new output mode changes only output URL, not IDs/count/domain assignment.

### Testing / acceptance
- Bulk batch of 10 and 300 yields exactly 10 and 300 links, respectively; no duplicates; preserves original IDs.
- An imported ID appears in its own XML response as a valid `<File name="original-id.html">` record.
- Browser loads XML, displays the file and permits explicit preview; no XML parsing error.
- GitHub and own-server uploads still work; failure of connector import is reported independently.
- Existing generator database, credentials, existing routes, and templates remain intact.
- No script injection via file names, descriptions, file sizes, or XML attributes.
- Provide patched code, backup details, SQL migrations if needed, verification steps and rollback instructions.

- `bulk-export.php` returns one `links[]` record per imported unique filename, with `filename`, `id`, `url`. Handle HTTP 207 partial success and report errors.

- For a browser-style `.html` path on our domain, select `https://html.surprisestream.com/connector-router/legacy/browser.html` as the Domain input. The authenticated `bulk-export.php` accepts a `browser_url` field and returns fully constructed per-ID links. Do not accept external browser hosts.
