# Connector Router — 30-day admin login patch

**Target:** `/home/surprisehtml/public_html/connector-router/`

This patch updates only `admin.php` and `lib/Core.php`. It leaves `config.local.php`, the approved-domain settings, batch routes, HTML Generator, and API tokens unchanged.

## Changes

- Admin login issues an HttpOnly, Secure (HTTPS), SameSite=Lax, host-only cookie named `CRREMEMBER`, expiring 30 days after login.
- Admin session cookie `CRSESSID` persists for 30 days, scoped to the installed Connector directory.
- When PHP deletes an idle session on shared hosting, the valid remember cookie automatically recreates an authenticated admin session. The admin session retains the original 30-day sign-in expiry; restoring it cannot extend authentication indefinitely.
- The remember token's **hash only** is stored in the existing private data directory (`remember-tokens.json`); actual token stays in the cookie.
- Logging out invalidates the current remember token and deletes both cookies.
- Login form and CSRF protection remain required; no API token is put into browser cookies.

## Install from SSH

Upload `connector-auth-30days.zip` into the Connector directory, then run:

```bash
cd /home/surprisehtml/public_html/connector-router || exit 1
mkdir -p /home/surprisehtml/connector-auth-backups
cp -p admin.php /home/surprisehtml/connector-auth-backups/admin.php.$(date +%Y%m%d-%H%M%S)
cp -p lib/Core.php /home/surprisehtml/connector-auth-backups/Core.php.$(date +%Y%m%d-%H%M%S)
unzip -o connector-auth-30days.zip admin.php lib/Core.php
chown surprisehtml:surprisehtml admin.php lib/Core.php
php -l admin.php
php -l lib/Core.php
```

Reload `https://html.surprisestream.com/connector-router/admin.php`, **log out and sign in once** to issue the persistent cookie. Go to `/connector-router/bulk-links.php`; it should no longer show `Admin authentication required`. Existing login cookies might have been issued with a different path, so a fresh login is needed after this update.

## Verify cookies

In Chrome DevTools → Application → Cookies, select `https://html.surprisestream.com`; expect `CRSESSID` and `CRREMEMBER` with expiration ~30 days after login, Path `/connector-router/`, Secure, HttpOnly. Do not share the cookie values.

If it still fails, confirm that `config.local.php` is readable by the PHP process and the private `data_dir` exists and is writable by `surprisehtml`. Report cookie *names, paths, expiration flags* only, not cookie values.

To undo, restore the saved `admin.php` and `Core.php`. This does not remove existing settings or routes.
